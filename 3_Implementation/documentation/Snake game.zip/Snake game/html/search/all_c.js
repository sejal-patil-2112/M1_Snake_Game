var searchData=
[
  ['score_0',['Score',['../snake1_8c.html#afc01ad71e5a2a27ebbbe7b7983cbb02b',1,'snake1.c']]],
  ['scoreonly_1',['Scoreonly',['../snake1_8c.html#a40a74cbfd7d2271a5a5caeb629197dd1',1,'snake1.c']]],
  ['snake1_2ec_2',['snake1.c',['../snake1_8c.html',1,'']]]
];
