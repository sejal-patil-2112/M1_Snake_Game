var searchData=
[
  ['up_0',['Up',['../snake1_8c.html#aa1e4dcf406c3281b132a396a60965e0f',1,'snake1.c']]]
];
