var searchData=
[
  ['direction_0',['direction',['../structcoordinate.html#a886d551d5381dc3e53f17825ffc51641',1,'coordinate']]]
];
