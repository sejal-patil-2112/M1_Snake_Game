var searchData=
[
  ['up_0',['UP',['../snake1_8c.html#a1965eaca47dbf3f87acdafc2208f04eb',1,'snake1.c']]]
];
