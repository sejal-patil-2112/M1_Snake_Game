var searchData=
[
  ['up_0',['UP',['../snake1_8c.html#a1965eaca47dbf3f87acdafc2208f04eb',1,'snake1.c']]],
  ['up_1',['Up',['../snake1_8c.html#aa1e4dcf406c3281b132a396a60965e0f',1,'snake1.c']]]
];
