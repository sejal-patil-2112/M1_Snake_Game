var searchData=
[
  ['gotoxy_0',['gotoxy',['../snake1_8c.html#ae824443b3f661414ba1f2718e17fe97d',1,'snake1.c']]],
  ['gotoxy_1',['GotoXY',['../snake1_8c.html#a08c7a02d581a5b018f840568a8289779',1,'snake1.c']]]
];
