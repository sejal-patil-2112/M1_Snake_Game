var searchData=
[
  ['coordinate_0',['coordinate',['../structcoordinate.html',1,'']]]
];
