var searchData=
[
  ['left_0',['Left',['../snake1_8c.html#ac268cc4e608aa0068c30f2e4a652b084',1,'snake1.c']]],
  ['load_1',['load',['../snake1_8c.html#a78f61ac2dd03bcba8e09ca20cd7d68e3',1,'snake1.c']]]
];
