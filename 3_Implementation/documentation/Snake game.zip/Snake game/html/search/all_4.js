var searchData=
[
  ['food_0',['food',['../snake1_8c.html#ab14451ea6560009c56ff7baf9a447552',1,'snake1.c']]],
  ['food_1',['Food',['../snake1_8c.html#a1951985f3541f595fc7800fbd6dc5535',1,'snake1.c']]]
];
